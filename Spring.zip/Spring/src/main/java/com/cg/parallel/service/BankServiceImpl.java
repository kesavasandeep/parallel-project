package com.cg.parallel.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parallel.beans.Account;
import com.cg.parallel.beans.Transaction;
import com.cg.parallel.dao.AccountRepository;
import com.cg.parallel.dao.TransactionRepository;
import com.cg.parallel.exception.AccountNotFoundException;


@Service
public class BankServiceImpl implements BankService {
	static Scanner scan = new Scanner(System.in);

	public java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Autowired
	private AccountRepository accountrepository;

	@Autowired
	private TransactionRepository transactionrepository;

	@Override
	public List<Account> createAcccount(Account acc) {
		accountrepository.save(acc);
		return getAllAccounts();
	}

	@Override
	public List<Account> getAllAccounts() {
		return accountrepository.findAll();
	}

	@Override
	public List<Account> deposit(int accNum, double amount) throws AccountNotFoundException {
		if (accountrepository.existsById(accNum)) {
			Account acc = accountrepository.findById(accNum).get();

			if (amount > 0) {
				acc.setInitialbalance(acc.getInitialbalance() + amount);
			} else {
				throw new AccountNotFoundException("Amount should be greater than zero");
			}
			accountrepository.save(acc);
			Transaction trans = new Transaction("CR", "Deposited", amount);
			java.sql.Date date1 = getCurrentDate();
			trans.setDate1(date1);
			trans.setAccount(acc);
			transactionrepository.save(trans);

		} else {
			throw new AccountNotFoundException("Account not Found");
		}
		return getAllAccounts();
	}

	@Override
	public List<Account> withdraw(int accNum, double amount) throws AccountNotFoundException {
		if (accountrepository.existsById(accNum)) {
			Account acc = accountrepository.findById(accNum).get();
			double initialbalnce = acc.getInitialbalance();
			if (amount <= 0) {
				throw new AccountNotFoundException("Amount should be greater than zero");
			} else {
				if (amount <= initialbalnce) {
					acc.setInitialbalance(acc.getInitialbalance() - amount);
				} else {
					throw new AccountNotFoundException("Withdrawl amount  is greater than BankBalance");
				}
				accountrepository.save(acc);
				Transaction trans = new Transaction("DR", "Debited", amount);
				java.sql.Date date1 = getCurrentDate();
				trans.setDate1(date1);
				trans.setAccount(acc);
				transactionrepository.save(trans);
			}
		} else {
			throw new AccountNotFoundException("Account not Found");
		}
		return getAllAccounts();
	}

	@Override
	public List<Account> fundsTransfer(int accNo1, int accNo2, double amount) throws AccountNotFoundException {
		if (accountrepository.existsById(accNo1) && accountrepository.existsById(accNo2)) {

			if (accNo1 == accNo2) {
				throw new AccountNotFoundException("Transfer to same Account will not Done");
			} else {
				Account amt1 = accountrepository.findById(accNo1).get();
				Account amt2 = accountrepository.findById(accNo2).get();
				double initialbalnce1 = amt1.getInitialbalance();
				if (amount <= initialbalnce1 && amount > 0) {
					amt1.setInitialbalance(amt1.getInitialbalance() - amount);
					amt2.setInitialbalance(amt2.getInitialbalance() + amount);
				} else {
					throw new AccountNotFoundException("Transfer amount is greater than Account balance");
				}

				accountrepository.save(amt1);
				accountrepository.save(amt2);
				Transaction trans1 = new Transaction("DR", "Debited", amount);
				java.sql.Date date1 = getCurrentDate();
				trans1.setDate1(date1);
				trans1.setAccount(amt1);
				transactionrepository.save(trans1);
				Transaction trans2 = new Transaction("CR", "Deposited", amount);
				java.sql.Date date2 = getCurrentDate();
				trans2.setDate1(date2);
				trans2.setAccount(amt2);
				transactionrepository.save(trans2);
			}

		} else {
			throw new AccountNotFoundException("Account not found enter valid Account numbers");
		}
		return getAllAccounts();

	}

	@Override
	public List<Transaction> getAllTransactions() {
		return transactionrepository.findAll();
	}

	@Override
	public double getInitialBalance(int accNum) throws AccountNotFoundException {
		if (accountrepository.existsById(accNum)) {

			return accountrepository.findById(accNum).get().getInitialbalance();
		} else {
			throw new AccountNotFoundException("Account with no=" + accNum + " not Found");
		}

	}

	@Override
	public List<Transaction> getTransactionByAccno(int accNum) {
		return transactionrepository.getTransactionByAccno(accNum);
	}

}
