package com.cg.parallel.exception;

public class AccountNotFoundException extends Exception {
	public AccountNotFoundException(String message)
	{
		super(message);
	}

}
