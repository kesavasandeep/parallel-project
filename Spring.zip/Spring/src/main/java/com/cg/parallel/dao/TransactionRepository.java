package com.cg.parallel.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.parallel.beans.Transaction;


public interface TransactionRepository extends JpaRepository<Transaction, Integer>{

	@Query("from Transaction where ACCOUNT_ACCNUM=:accNum")
	List<Transaction> getTransactionByAccno(@RequestParam("ACCOUNT_ACCNUM") int accNum);
}
