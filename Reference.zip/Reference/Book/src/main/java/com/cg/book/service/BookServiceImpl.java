package com.cg.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.beans.Book;
import com.cg.book.dao.BookRepository;
import com.cg.book.exception.BookException;


@Service
public class BookServiceImpl implements BookService{
	
	@Autowired
	private BookRepository bookrepository;

	@Override
	public List<Book> addBook(Book buk) throws BookException {
		bookrepository.save(buk);
		return bookrepository.findAll();
	}
	@Override
	public List<Book> getAllbooks() throws BookException {
		try {
			return bookrepository.findAll();

		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public Book getBookById(int id) throws BookException {
		if (!bookrepository.existsById(id)) {

			throw new BookException("Book with Id " + id + " does not exist");
		}
		return bookrepository.findById(id).get();
	}

	@Override
	public List<Book> updatebook(Book buk) throws BookException {
		if (bookrepository.existsById(buk.getId())) {
			bookrepository.save(buk);
			return getAllbooks();
		}
		throw new BookException("Book with Id " + buk.getId() + " doesn't exist");
	}

	@Override
	public List<Book> deleteBook(int id) throws BookException {
		if (!bookrepository.existsById(id)) {
			throw new BookException("Book with Id " + id + " doesn't exists");
		}
		bookrepository.deleteById(id);
		return getAllbooks();
	}

}