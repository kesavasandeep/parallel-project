package com.cg.book.exception;

public class BookException extends Exception{
	
	public BookException() {
		super();
	}

	public BookException(String message) {
		super(message);
	}

}
