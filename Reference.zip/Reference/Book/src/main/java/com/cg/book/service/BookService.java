package com.cg.book.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.book.beans.Book;
import com.cg.book.exception.BookException;


public interface BookService {

	List<Book> addBook(Book buk) throws BookException;
	List<Book> getAllbooks()  throws BookException;
	Book getBookById(int id) throws BookException;
	List<Book> updatebook(Book stud) throws BookException;
	List<Book> deleteBook(int id) throws BookException;
	

	

	

	

}
