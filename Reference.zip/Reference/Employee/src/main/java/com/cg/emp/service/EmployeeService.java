package com.cg.emp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.emp.beans.Employee;
import com.cg.emp.exception.EmployeeException;

@Service
public interface EmployeeService {

	List<Employee>getAllEmployees() throws EmployeeException;
	List<Employee>addEmployee(Employee emp) throws EmployeeException;
	Employee getEmployeeById(int id) throws EmployeeException;
	List<Employee>deleteEmployee(int id) throws EmployeeException;
	List<Employee>updateEmployee(Employee emp) throws EmployeeException;
	List<Employee> getEmployeeByGender(String gender) throws EmployeeException;
}
