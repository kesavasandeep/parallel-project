package com.cg.cour.exception;

public class CourseException extends Exception {
	
	public CourseException() {
		super();
	}

	public CourseException(String message) {
		super(message);
	}


}
