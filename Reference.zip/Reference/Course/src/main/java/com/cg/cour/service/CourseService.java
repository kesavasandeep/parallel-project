package com.cg.cour.service;

import java.util.List;

import com.cg.cour.beans.Course;
import com.cg.cour.exception.CourseException;

public interface CourseService {
	
	List<Course> getAllCourses() throws CourseException;
	List<Course> addCourse(Course cour) throws CourseException;
	Course getCoursesById(String id) throws CourseException; 
	List<Course> updateCourse(Course cour) throws CourseException;
	List<Course> deleteCourse(String id) throws CourseException;
	List<Course> getCourseBymode(String mode)throws CourseException;
}
