package com.cg.cour.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cour.beans.Course;
import com.cg.cour.dao.CourseRepository;
import com.cg.cour.exception.CourseException;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public List<Course> getAllCourses() throws CourseException {
		try {
			return courseRepository.findAll();

		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> addCourse(Course cour) throws CourseException {
			courseRepository.save(cour);
		return courseRepository.findAll();
	}

	@Override
	public Course getCoursesById(String id) throws CourseException {
		if (!courseRepository.existsById(id)) {

			throw new CourseException("Course with Id " + id + " does not exist");
		}
		return courseRepository.findById(id).get();
	}

	@Override
	public List<Course> updateCourse(Course cour) throws CourseException {
		if(courseRepository.existsById(cour.getCourseId())){
			courseRepository.save(cour);
			return getAllCourses();
		}
		throw new CourseException("Product with Id "+cour.getCourseId() +" doesn't exist");
}
	@Override
	public List<Course> deleteCourse(String id) throws CourseException {
		if(!courseRepository.existsById(id)) {
			throw new CourseException("Product with Id "+id+" doesn't exists");
		}
		courseRepository.deleteById(id);
		return getAllCourses();
	}

	@Override
	public List<Course> getCourseBymode(String mode) throws CourseException {
			return courseRepository.getCourseBymode(mode);
			
	}

}
