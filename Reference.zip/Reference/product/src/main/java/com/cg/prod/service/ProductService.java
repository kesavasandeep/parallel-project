package com.cg.prod.service;

import java.util.List;
import com.cg.prod.beans.Product;
import com.cg.prod.exception.ProductException;

public interface ProductService {
	List<Product> getAllProducts() throws ProductException;

	List<Product> addproduct(Product prod) throws ProductException;

	Product getProductById(int id) throws ProductException;

	List<Product> updateProduct(Product emp) throws ProductException;

	List<Product> deleteProduct(int id) throws ProductException;
	
    List<Product> getProductCategory(String category) throws ProductException;


}
