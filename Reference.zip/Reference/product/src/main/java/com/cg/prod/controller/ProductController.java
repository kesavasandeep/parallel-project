package com.cg.prod.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.prod.beans.Product;
import com.cg.prod.exception.ProductException;
import com.cg.prod.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productservice;

	@RequestMapping("/product")
	public List<Product> getProducts() throws ProductException {
		return productservice.getAllProducts();

	}

	@GetMapping("/product/{id}")
	public Product getProductById(@PathVariable int id) throws ProductException {
		return productservice.getProductById(id);

	}

	@PostMapping("/addproduct")
	public List<Product> addProduct(@RequestBody Product prod) throws ProductException {
		return productservice.addproduct(prod);
	}

	@DeleteMapping("/delete/{id}")
	public List<Product> deleteProduct(@PathVariable int id) throws ProductException {
		return productservice.deleteProduct(id);
	}

	@PutMapping("/update")
	public List<Product> updateProduct(@RequestBody Product prod) throws ProductException {

		return productservice.updateProduct(prod);
	}

	@GetMapping("/products/category")
    public List<Product> getEmployeeByGender(@RequestParam String category) throws ProductException{
        return productservice.getProductCategory(category);
    }
}

