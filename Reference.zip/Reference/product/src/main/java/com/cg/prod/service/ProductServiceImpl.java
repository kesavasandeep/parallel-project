package com.cg.prod.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.beans.Product;
import com.cg.prod.dao.ProductRepository;
import com.cg.prod.exception.ProductException;
@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() throws ProductException {
		try {
			return productRepository.findAll();

		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public Product getProductById(int id) throws ProductException {
		if (!productRepository.existsById(id)) {

			throw new ProductException("Product with Id " + id + " does not exist");
		}
		
		return productRepository.findById(id).get();
	}

	@Override
    public List<Product> addproduct(Product prod) throws ProductException {
        if(productRepository.existsById(prod.getId())) {
           
           
            /*
             * imports.save(p); return imports.findAll();
             */
            throw new ProductException("Product with id "+prod.getId()+" already exists");
        }
        double discount = (prod.getPrice()*25*prod.getQuantity())/(100);
        
        prod.setDiscount(discount);
        productRepository.save(prod);
        return productRepository.findAll();
    }
	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if(!productRepository.existsById(id)) {
			throw new ProductException("Product with Id "+id+" doesn't exists");
		}
		
		productRepository.deleteById(id);
		return getAllProducts();
	}

	@Override
	public List<Product> updateProduct(Product cour) throws ProductException {
			if(productRepository.existsById(cour.getId())){
				productRepository.save(cour);
				return getAllProducts();
			}
			throw new ProductException("Product with Id "+cour.getId() +" doesn't exist");
	}

    @Override
    public List<Product> getProductCategory(String category) throws ProductException {
       
        return productRepository.findProductByCategory(category);
    }


}
