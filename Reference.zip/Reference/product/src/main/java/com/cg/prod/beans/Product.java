package com.cg.prod.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@Entity
public class Product {

	@Id
	@SequenceGenerator(name = "prodid_seq", sequenceName = "pro_seq", allocationSize = 1, initialValue = 5001)
	@GeneratedValue(generator = "prodid_seq")
	private int id;
	private String name;
	@Pattern(regexp = "(MOBILE|TV|LAPTOP)", message = "Category must be TV,MOBILE,LAptop")
	private String category;
	@Min(value = 1)
	private int quantity;
	private double price;
	@Column(name = "disc")
	private double discount;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", category=" + category + ", quantity=" + quantity + ", price="
				+ price + ", discount=" + discount + "]";
	}

}
